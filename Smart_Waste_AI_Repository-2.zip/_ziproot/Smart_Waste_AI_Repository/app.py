from pathlib import Path
import json
import streamlit as st
from PIL import Image
import numpy as np

from smartwaste.inference import load_model, predict_image, model_status
from smartwaste.guidance import MATERIALS, recycling_advice

ROOT = Path(__file__).parent
st.set_page_config(page_title="Smart Waste AI", page_icon="♻️", layout="wide")

# Palette inspired by the reference: deep teal, warm gold, light mint.
st.markdown("""
<style>
:root { --teal:#0b4944; --gold:#e9b13b; --mint:#e8f1ed; }
.stApp { background: #f4f6f2; }
.block-container { padding-top: 1.6rem; max-width: 1400px; }
.hero { background: linear-gradient(115deg,#0b4944,#12665c); color:white;
        padding:28px 32px; border-radius:18px; margin-bottom:18px; }
.hero h1 { color:white; margin:0; font-size:2.25rem; }
.hero p { color:#e4f0eb; margin:8px 0 0; }
.kpi { background:white; border:1px solid #d9e3de; border-radius:14px; padding:18px; }
.kpi .label { color:#66756f; font-size:.9rem; }
.kpi .value { color:#0b4944; font-size:1.45rem; font-weight:700; }
.section { color:#0b4944; font-size:1.35rem; font-weight:700; margin: 14px 0 8px; }
.note { background:#fff7e4; border-left:4px solid #e9b13b; padding:12px 14px; border-radius:8px; }
.small { color:#66756f; font-size:.88rem; }
</style>
""", unsafe_allow_html=True)

if "page" not in st.session_state:
    st.session_state.page = "Overview"

with st.sidebar:
    st.markdown("## ♻️ Smart Waste AI")
    st.caption("Waste recognition & recycling assistant")
    page = st.radio("Navigation", ["Overview", "Classify an Image", "Recycling Guide", "Model & Evaluation", "Dataset Setup", "About"], label_visibility="collapsed")
    st.divider()
    status = model_status(ROOT / "artifacts")
    st.write("**Model status**")
    st.success("Trained model found") if status["ready"] else st.warning("Training required")
    st.caption("Predictions and metrics are shown only when the relevant model/artifacts exist.")

st.markdown("""
<div class="hero">
  <h1>Smart Waste AI</h1>
  <p>Computer vision for waste sorting — built for transparent, measurable recycling support.</p>
</div>
""", unsafe_allow_html=True)

if page == "Overview":
    a,b,c = st.columns(3)
    with a: st.markdown('<div class="kpi"><div class="label">Core task</div><div class="value">Image classification</div><div class="small">Predict a waste category from a photo</div></div>', unsafe_allow_html=True)
    with b: st.markdown('<div class="kpi"><div class="label">Workflow</div><div class="value">Train → Evaluate</div><div class="small">Metrics generated from held-out data</div></div>', unsafe_allow_html=True)
    with c: st.markdown('<div class="kpi"><div class="label">Output</div><div class="value">Prediction + guidance</div><div class="small">Category, confidence, disposal advice</div></div>', unsafe_allow_html=True)
    st.markdown('<div class="section">How it works</div>', unsafe_allow_html=True)
    x,y,z = st.columns(3)
    x.info("**1 · Upload**\n\nChoose a clear image of one main waste item.")
    y.info("**2 · Predict**\n\nA trained CNN analyzes the image. The app will not invent a prediction if no model is available.")
    z.info("**3 · Act**\n\nRead category-specific sorting advice and check local rules.")
    st.markdown('<div class="note">This package includes training and evaluation code, but it does not ship with a pre-trained model or fabricated scores. Train it on a labeled dataset to enable real predictions.</div>', unsafe_allow_html=True)
    st.markdown('<div class="section">Waste categories supported by the starter configuration</div>', unsafe_allow_html=True)
    cols = st.columns(3)
    for i, (name, info) in enumerate(MATERIALS.items()):
        with cols[i % 3]:
            st.markdown(f'<div class="kpi"><b>{info["icon"]} {name}</b><p class="small">{info["short"]}</p></div>', unsafe_allow_html=True)

elif page == "Classify an Image":
    st.markdown('<div class="section">Upload a waste image</div>', unsafe_allow_html=True)
    uploaded = st.file_uploader("Image file", type=["jpg","jpeg","png","webp"])
    if uploaded:
        image = Image.open(uploaded).convert("RGB")
        left,right = st.columns([1,1])
        with left:
            st.image(image, caption="Uploaded image", use_container_width=True)
        with right:
            model = load_model(ROOT / "artifacts")
            if model is None:
                st.warning("No trained model was found. Add labeled images and run `python train.py` first.")
                st.code("python train.py --data data/waste_dataset --epochs 10")
            else:
                try:
                    result = predict_image(image, model, ROOT / "artifacts")
                    st.subheader(result["label"])
                    st.metric("Model confidence", f'{result["confidence"]:.1%}')
                    st.progress(min(1.0, max(0.0, result["confidence"])))
                    advice = recycling_advice(result["label"])
                    st.markdown("**Suggested handling**")
                    st.write(advice)
                    st.caption("Confidence is the model's softmax score, not a guarantee of correctness.")
                except Exception as e:
                    st.error(f"Prediction failed: {e}")
    else:
        st.info("Upload an image to begin. Use a clear photo with one main object and a simple background.")

elif page == "Recycling Guide":
    st.markdown('<div class="section">Recycling guide</div>', unsafe_allow_html=True)
    chosen = st.selectbox("Select material", list(MATERIALS.keys()))
    st.markdown(f"### {MATERIALS[chosen]['icon']} {chosen}")
    st.write(recycling_advice(chosen))
    st.caption("Rules vary by municipality. Confirm local collection requirements before disposal.")

elif page == "Model & Evaluation":
    st.markdown('<div class="section">Model status and measured evaluation</div>', unsafe_allow_html=True)
    status = model_status(ROOT / "artifacts")
    if status["ready"]:
        st.success("Model artifact detected.")
    else:
        st.warning("No trained model artifact detected yet.")
    metrics_path = ROOT / "artifacts" / "evaluation.json"
    if metrics_path.exists():
        metrics = json.loads(metrics_path.read_text(encoding="utf-8"))
        st.caption(f"Generated by evaluation run: {metrics.get('timestamp', 'timestamp not recorded')}")
        cols = st.columns(4)
        for col, key, label in zip(cols, ["accuracy","precision_macro","recall_macro","f1_macro"], ["Accuracy","Macro Precision","Macro Recall","Macro F1"]):
            val = metrics.get(key)
            col.metric(label, f"{val:.3f}" if isinstance(val,(int,float)) else "N/A")
        st.write("**Per-class report**")
        if "classification_report" in metrics:
            st.json(metrics["classification_report"])
        st.write("**Confusion matrix**")
        if "confusion_matrix" in metrics:
            st.dataframe(metrics["confusion_matrix"], use_container_width=True)
    else:
        st.info("No evaluation results exist yet. Run `python evaluate.py --data data/waste_dataset/test` after training. Metrics will appear here only after a successful evaluation.")
    st.markdown("**Evaluation protocol**")
    st.write("Keep the test set separate from training and validation. Report the dataset source, class counts, split method, and any known imbalance alongside scores.")

elif page == "Dataset Setup":
    st.markdown('<div class="section">Dataset folder structure</div>', unsafe_allow_html=True)
    st.write("Place labeled images into one folder per class. The class folder names become the model labels.")
    st.code("""data/waste_dataset/
  train/
    cardboard/
    glass/
    metal/
    paper/
    plastic/
    trash/
  val/
    cardboard/
    glass/
    metal/
    paper/
    plastic/
    trash/
  test/
    cardboard/
    glass/
    metal/
    paper/
    plastic/
    trash/""")
    st.warning("Only use images you have permission to use. Avoid near-duplicate images across splits; split by source/object when possible to reduce leakage.")
    st.write("The starter does not bundle a dataset. Dataset licensing, class definitions, and class balance should be documented in `data/DATASET_NOTES.md`.")

elif page == "About":
    st.markdown('<div class="section">Project components</div>', unsafe_allow_html=True)
    st.write("- **Streamlit:** user interface\n- **TensorFlow/Keras:** CNN training and inference\n- **scikit-learn:** metrics and confusion matrix\n- **Pillow:** image loading and preprocessing\n- **JSON:** saved labels and evaluation output")
    st.write("This is an educational prototype, not a substitute for local waste authority instructions. It classifies only the classes represented in the dataset.")
