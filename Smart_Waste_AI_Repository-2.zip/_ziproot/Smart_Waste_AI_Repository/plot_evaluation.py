"""Create a PNG chart from a real artifacts/evaluation.json file."""
import json
from pathlib import Path

def main():
    source=Path('artifacts/evaluation.json')
    if not source.exists(): raise SystemExit('Missing artifacts/evaluation.json. Run evaluate.py first.')
    try: import matplotlib.pyplot as plt
    except ImportError: raise SystemExit('Install matplotlib: pip install matplotlib')
    d=json.loads(source.read_text(encoding='utf-8'))
    names=['Accuracy','Macro precision','Macro recall','Macro F1']
    vals=[d['accuracy'],d['precision_macro'],d['recall_macro'],d['f1_macro']]
    fig,ax=plt.subplots(figsize=(8,4.8)); bars=ax.bar(names,vals)
    ax.set_ylim(0,1); ax.set_ylabel('Score'); ax.set_title(f"Held-out test metrics (n={d['test_samples']})")
    ax.grid(axis='y',alpha=.25); ax.bar_label(bars,fmt='%.3f',padding=3)
    fig.tight_layout(); out=Path('artifacts/evaluation_metrics.png'); fig.savefig(out,dpi=160); print(f'Saved {out}')
if __name__=='__main__': main()
