# Publish Smart Waste AI to GitHub

Repository: https://github.com/Yosfamgad6/Smart-Waste-AI

1. Download and extract `Smart_Waste_AI_Repository.zip`.
2. Open the repository on GitHub and click **Add file → Upload files**.
3. Upload the extracted project files/folders (not the ZIP archive).
4. Commit the changes with a message such as `Add complete Smart Waste AI prototype`.
5. Keep dataset images and trained model weights out of Git unless their licenses and size are suitable.

## Run

```bash
pip install -r requirements.txt
python prepare_dataset.py --source data/raw_dataset --output data/waste_dataset --copy
python train.py --data data/waste_dataset --epochs 10
python evaluate.py --data data/waste_dataset/test
streamlit run app.py
```

Dataset images and a trained model are intentionally not bundled. Therefore the classifier and actual evaluation metrics will become available only after preparing data and running training/evaluation.
