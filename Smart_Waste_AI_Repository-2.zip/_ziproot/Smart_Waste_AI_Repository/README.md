# Smart Waste AI — complete educational prototype

A Streamlit app plus a TensorFlow/Keras training and evaluation pipeline for classifying common waste images. The UI follows the reference project's deep-teal, mint, and gold visual language.

## Honest status
- No pre-trained model is included.
- No dataset is bundled.
- No performance numbers are hard-coded.
- The classifier becomes available only after you provide labeled images and run training.
- Metrics are written only after evaluation on the explicit test split.

## 1. Setup

Python 3.10 or 3.11 is recommended. TensorFlow support depends on OS, Python version, and hardware.

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
```

## 2. Prepare data

See `data/DATASET_NOTES.md`. Put images into `train`, `val`, and `test` directories, with the same class subdirectories in each. Default labels: cardboard, glass, metal, paper, plastic, trash.

## 3. Train

```bash
python train.py --data data/waste_dataset --epochs 10 --batch-size 32
```

Optional fine-tuning stage:
```bash
python train.py --data data/waste_dataset --epochs 10 --fine-tune
```

Training writes `artifacts/waste_classifier.keras`, `artifacts/labels.json`, and `artifacts/training_summary.json`.

## 4. Evaluate once on held-out test data

```bash
python evaluate.py --data data/waste_dataset/test
```

This creates `artifacts/evaluation.json`, including accuracy, macro precision/recall/F1, per-class report, and confusion matrix. Do not report scores without identifying the dataset and split.

## 5. Run the UI

```bash
streamlit run app.py
```

Use the sidebar to navigate between image classification, recycling guide, model evaluation, dataset setup, and project information.

## Project tree

```text
Smart_Waste_AI_Complete/
├── app.py
├── train.py
├── evaluate.py
├── requirements.txt
├── smartwaste/
│   ├── model.py
│   ├── inference.py
│   └── guidance.py
├── data/
│   └── DATASET_NOTES.md
└── artifacts/
    └── README.md
```

## Main technologies
- Streamlit — web UI
- TensorFlow/Keras + MobileNetV2 — transfer-learning image classifier
- scikit-learn — evaluation metrics
- Pillow/NumPy — image preprocessing

## Limitations
- The model predicts among the labels it was trained on; it is not a universal waste expert.
- Softmax confidence is not calibrated probability.
- Real-world photos, mixed materials, lighting, and background changes can reduce performance.
- Disposal advice is general; local municipality rules take priority.

## 6. Optional: split a raw dataset automatically

Place licensed images in `data/raw_dataset/<class_name>/` (one folder per class), then run:

```bash
python prepare_dataset.py --source data/raw_dataset --output data/waste_dataset --copy
```

This creates reproducible train/validation/test folders (70/15/15 by default). With `--copy`, original files remain untouched. Review the output counts and ensure near-duplicate images do not cross splits.

## 7. Publish to GitHub

See `GITHUB_UPLOAD.md`. The project archive is prepared for manual upload; no push to GitHub is performed automatically from this environment.

## 8. Plot real evaluation metrics

After `evaluate.py` creates `artifacts/evaluation.json`, run:

```bash
python plot_evaluation.py
```

This saves `artifacts/evaluation_metrics.png` from actual held-out test results.
