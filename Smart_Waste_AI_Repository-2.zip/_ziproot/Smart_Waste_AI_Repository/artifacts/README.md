# Model artifacts

This directory is intentionally empty in the delivered source project. No pretrained Smart Waste AI model or measured metrics are bundled.

After preparing a licensed dataset, run `python train.py`, then `python evaluate.py --data data/waste_dataset/test`. The training/evaluation scripts generate the model, class labels, training summary, and test metrics here.
