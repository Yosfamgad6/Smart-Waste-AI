MATERIALS = {
    "cardboard": {"icon":"📦", "short":"Clean boxes and corrugated packaging."},
    "glass": {"icon":"🍾", "short":"Bottles and jars; handle broken glass carefully."},
    "metal": {"icon":"🥫", "short":"Clean cans and small metal packaging."},
    "paper": {"icon":"📄", "short":"Clean, dry paper and newspapers."},
    "plastic": {"icon":"🧴", "short":"Bottles and containers accepted by local programs."},
    "trash": {"icon":"🗑️", "short":"Mixed or non-recyclable items in this label set."},
}

ADVICE = {
    "cardboard": "Keep cardboard dry and clean. Flatten boxes. Remove food residue and check whether tape or liners need to be removed under local rules.",
    "glass": "Separate reusable bottles and jars where accepted. Do not place loose broken glass into recycling bins unless local guidance allows it; wrap and label it safely.",
    "metal": "Empty and rinse cans when practical. Sharp edges can cut; do not compact cans by hand.",
    "paper": "Keep paper dry and free from food or oil. Greasy tissues and heavily soiled paper are often not accepted in paper recycling.",
    "plastic": "Empty and rinse containers. Resin codes do not guarantee local recyclability; check the rules for your municipality.",
    "trash": "This model label means the image resembles the dataset's general trash class. Check local hazardous-waste or e-waste routes for batteries, electronics, chemicals, and lamps.",
}

def recycling_advice(label):
    return ADVICE.get(str(label).strip().lower(), "Check local waste guidance for this material. The model label may not match every local recycling category.")
