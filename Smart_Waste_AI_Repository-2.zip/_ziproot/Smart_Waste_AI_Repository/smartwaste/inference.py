from pathlib import Path
import json
import numpy as np
from PIL import Image

def model_status(artifacts_dir):
    p = Path(artifacts_dir)
    return {"ready": (p / "waste_classifier.keras").exists() and (p / "labels.json").exists()}

def load_model(artifacts_dir):
    p = Path(artifacts_dir)
    model_path, labels_path = p / "waste_classifier.keras", p / "labels.json"
    if not model_path.exists() or not labels_path.exists():
        return None
    try:
        from tensorflow import keras
        model = keras.models.load_model(model_path)
        model.smartwaste_labels = json.loads(labels_path.read_text(encoding="utf-8"))["classes"]
        return model
    except Exception:
        return None

def predict_image(image: Image.Image, model, artifacts_dir):
    p = Path(artifacts_dir)
    labels = json.loads((p / "labels.json").read_text(encoding="utf-8"))["classes"]
    image = image.convert("RGB").resize((224, 224))
    arr = np.asarray(image, dtype=np.float32)[None, ...]
    probs = model.predict(arr, verbose=0)[0]
    idx = int(np.argmax(probs))
    return {"label": labels[idx], "confidence": float(probs[idx]), "probabilities": {labels[i]: float(v) for i, v in enumerate(probs)}}
