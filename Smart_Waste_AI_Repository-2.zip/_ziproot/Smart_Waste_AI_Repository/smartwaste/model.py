from tensorflow import keras
from tensorflow.keras import layers

DEFAULT_IMAGE_SIZE = (224, 224)

def build_model(num_classes: int, image_size=DEFAULT_IMAGE_SIZE):
    """Build a compact transfer-learning classifier using MobileNetV2."""
    inputs = keras.Input(shape=(*image_size, 3), name="image")
    x = layers.Rescaling(1.0 / 127.5, offset=-1)(inputs)
    backbone = keras.applications.MobileNetV2(
        input_shape=(*image_size, 3), include_top=False, weights="imagenet"
    )
    backbone.trainable = False
    x = backbone(x, training=False)
    x = layers.GlobalAveragePooling2D()(x)
    x = layers.Dropout(0.25)(x)
    outputs = layers.Dense(num_classes, activation="softmax", name="class_probabilities")(x)
    model = keras.Model(inputs, outputs, name="smart_waste_mobilenetv2")
    model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=1e-3),
        loss="categorical_crossentropy",
        metrics=["accuracy"],
    )
    return model
