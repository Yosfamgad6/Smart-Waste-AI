import argparse, json
from pathlib import Path
from datetime import datetime, timezone
import numpy as np

def main():
    parser = argparse.ArgumentParser(description="Evaluate trained Smart Waste AI model on held-out test data.")
    parser.add_argument("--data", default="data/waste_dataset/test", help="Test folder with one subfolder per class")
    parser.add_argument("--batch-size", type=int, default=32)
    args = parser.parse_args()
    try:
        from tensorflow import keras
        from sklearn.metrics import accuracy_score, precision_recall_fscore_support, confusion_matrix, classification_report
    except ImportError as exc:
        raise SystemExit("Install dependencies with: pip install -r requirements.txt") from exc

    model_path, labels_path = Path("artifacts/waste_classifier.keras"), Path("artifacts/labels.json")
    if not model_path.exists() or not labels_path.exists():
        raise SystemExit("Trained model missing. Run python train.py first.")
    test_dir = Path(args.data)
    if not test_dir.exists():
        raise SystemExit(f"Test directory not found: {test_dir}")
    labels = json.loads(labels_path.read_text(encoding="utf-8"))["classes"]
    ds = keras.utils.image_dataset_from_directory(test_dir, image_size=(224,224), batch_size=args.batch_size, shuffle=False, label_mode="int")
    if ds.class_names != labels:
        raise SystemExit(f"Test class folders {ds.class_names} do not match trained labels {labels}.")
    y_true = np.concatenate([y.numpy() for _, y in ds], axis=0)
    probs = model_path
    model = keras.models.load_model(model_path)
    pred_probs = model.predict(ds, verbose=1)
    y_pred = np.argmax(pred_probs, axis=1)
    acc = accuracy_score(y_true, y_pred)
    precision, recall, f1, _ = precision_recall_fscore_support(y_true, y_pred, average="macro", zero_division=0)
    cm = confusion_matrix(y_true, y_pred, labels=list(range(len(labels))))
    report = classification_report(y_true, y_pred, labels=list(range(len(labels))), target_names=labels, output_dict=True, zero_division=0)
    output = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "test_samples": int(len(y_true)),
        "classes": labels,
        "accuracy": float(acc),
        "precision_macro": float(precision),
        "recall_macro": float(recall),
        "f1_macro": float(f1),
        "confusion_matrix": cm.tolist(),
        "classification_report": report,
        "note": "Scores are specific to this dataset and split; they are not a guarantee of real-world performance."
    }
    Path("artifacts").mkdir(exist_ok=True)
    Path("artifacts/evaluation.json").write_text(json.dumps(output, indent=2), encoding="utf-8")
    print(json.dumps({k: output[k] for k in ["test_samples","accuracy","precision_macro","recall_macro","f1_macro"]}, indent=2))
    print("Saved full metrics to artifacts/evaluation.json")

if __name__ == "__main__":
    main()
