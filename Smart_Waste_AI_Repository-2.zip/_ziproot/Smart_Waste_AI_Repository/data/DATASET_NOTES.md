# Dataset setup and documentation

No image dataset is bundled in this project. This avoids redistributing images without checking their license and avoids implying that the model has already been trained.

## Required layout

```text
data/waste_dataset/
  train/
    cardboard/
    glass/
    metal/
    paper/
    plastic/
    trash/
  val/
    cardboard/
    glass/
    metal/
    paper/
    plastic/
    trash/
  test/
    cardboard/
    glass/
    metal/
    paper/
    plastic/
    trash/
```

You may use a public waste-classification dataset (for example, a dataset hosted on Kaggle or another repository) only after checking its license and usage conditions. Do not assume that any dataset is free for every use.

## Data quality checklist

- Record dataset name, source URL, license, download date, and class definitions.
- Record the number of images in each class and in each split.
- Keep test data out of training and model selection.
- Avoid placing near-duplicate photos or photos of the same physical item in multiple splits.
- Check image labels manually; ambiguous and multi-material objects need a documented labeling rule.
- Use a fixed random seed and record it.
- Report class-wise precision/recall as well as aggregate metrics.
- If deploying in Egypt, verify local recycling categories and collection practices; the model's classes may not map directly to local services.
