Place licensed labeled images here following the folder structure in ../DATASET_NOTES.md. No images are bundled by default.
