"""Split a raw image dataset into train/val/test folders per class.
Expected input: data/raw_dataset/<class_name>/*.(jpg|jpeg|png|webp)
This script copies files; it does not download or redistribute third-party images.
"""
import argparse, random, shutil
from pathlib import Path

EXTS = {'.jpg', '.jpeg', '.png', '.webp', '.bmp'}
def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source', default='data/raw_dataset')
    p.add_argument('--output', default='data/waste_dataset')
    p.add_argument('--train', type=float, default=.70)
    p.add_argument('--val', type=float, default=.15)
    p.add_argument('--seed', type=int, default=42)
    p.add_argument('--copy', action='store_true', help='Copy instead of moving files')
    a = p.parse_args()
    if a.train <= 0 or a.val <= 0 or a.train + a.val >= 1:
        p.error('train and val must be positive and their sum must be below 1')
    src, out = Path(a.source), Path(a.output)
    if not src.exists(): raise SystemExit(f'Source folder not found: {src}')
    classes = [d for d in src.iterdir() if d.is_dir()]
    if len(classes) < 2: raise SystemExit('Expected at least two class folders inside source.')
    rng = random.Random(a.seed); total = 0
    for cls in sorted(classes):
        files = [f for f in cls.rglob('*') if f.is_file() and f.suffix.lower() in EXTS]
        if len(files) < 3:
            print(f'SKIP {cls.name}: needs at least 3 images, found {len(files)}'); continue
        rng.shuffle(files)
        n = len(files); n_train = max(1, int(n*a.train)); n_val = max(1, int(n*a.val))
        if n_train+n_val >= n: n_train, n_val = n-2, 1
        split_files = [('train', files[:n_train]), ('val', files[n_train:n_train+n_val]), ('test', files[n_train+n_val:])]
        for split, items in split_files:
            dest = out/split/cls.name; dest.mkdir(parents=True, exist_ok=True)
            for i, f in enumerate(items):
                target = dest/f.name
                if target.exists(): target = dest/f'{f.stem}_{i}{f.suffix}'
                (shutil.copy2 if a.copy else shutil.move)(str(f), str(target))
            print(f'{split:5s} | {cls.name:12s} | {len(items):5d}')
            total += len(items)
    print(f'\nPrepared {total} images at {out.resolve()}')
    print('Important: review the dataset license and labels; prevent near-duplicate leakage across splits.')
if __name__ == '__main__': main()
