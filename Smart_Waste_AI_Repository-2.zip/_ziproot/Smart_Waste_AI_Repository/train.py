import argparse, json, random, os
from pathlib import Path
from datetime import datetime, timezone

def main():
    parser = argparse.ArgumentParser(description="Train Smart Waste AI image classifier.")
    parser.add_argument("--data", default="data/waste_dataset", help="Root containing train/ and val/ class folders")
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--fine-tune", action="store_true", help="Unfreeze final MobileNetV2 layers for a second training stage")
    args = parser.parse_args()
    random.seed(args.seed)
    os.environ["PYTHONHASHSEED"] = str(args.seed)

    try:
        import tensorflow as tf
        from tensorflow import keras
        from smartwaste.model import build_model
    except ImportError as exc:
        raise SystemExit("TensorFlow is not installed. Install requirements with: pip install -r requirements.txt") from exc

    root = Path(args.data)
    train_dir, val_dir = root / "train", root / "val"
    if not train_dir.exists() or not val_dir.exists():
        raise SystemExit(f"Expected class folders under {train_dir} and {val_dir}. See data/DATASET_NOTES.md.")
    image_size = (224, 224)
    train_ds = keras.utils.image_dataset_from_directory(train_dir, image_size=image_size, batch_size=args.batch_size, seed=args.seed, label_mode="categorical")
    val_ds = keras.utils.image_dataset_from_directory(val_dir, image_size=image_size, batch_size=args.batch_size, shuffle=False, label_mode="categorical")
    class_names = train_ds.class_names
    if len(class_names) < 2:
        raise SystemExit("At least two class folders are required.")
    if val_ds.class_names != class_names:
        raise SystemExit("Train and validation class folders must match exactly.")
    autotune = tf.data.AUTOTUNE
    train_ds = train_ds.prefetch(autotune)
    val_ds = val_ds.prefetch(autotune)

    model = build_model(len(class_names), image_size)
    callbacks = [
        keras.callbacks.EarlyStopping(monitor="val_loss", patience=3, restore_best_weights=True),
        keras.callbacks.ModelCheckpoint("artifacts/best_checkpoint.keras", monitor="val_loss", save_best_only=True),
    ]
    Path("artifacts").mkdir(exist_ok=True)
    history = model.fit(train_ds, validation_data=val_ds, epochs=args.epochs, callbacks=callbacks)
    if args.fine_tune:
        backbone = next((layer for layer in model.layers if isinstance(layer, keras.Model)), None)
        if backbone is not None:
            backbone.trainable = True
            for layer in backbone.layers[:-30]:
                layer.trainable = False
            model.compile(optimizer=keras.optimizers.Adam(learning_rate=1e-5), loss="categorical_crossentropy", metrics=["accuracy"])
            model.fit(train_ds, validation_data=val_ds, epochs=max(1, args.epochs // 2), callbacks=callbacks)
    best = Path("artifacts/best_checkpoint.keras")
    if best.exists():
        model = keras.models.load_model(best)
    model.save("artifacts/waste_classifier.keras")
    Path("artifacts/labels.json").write_text(json.dumps({"classes": class_names}, indent=2), encoding="utf-8")
    summary = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "framework": f"TensorFlow {tf.__version__}",
        "architecture": "MobileNetV2 transfer learning",
        "image_size": list(image_size),
        "classes": class_names,
        "epochs_requested": args.epochs,
        "training_samples": int(len(list((train_dir).rglob("*.*")))),
        "validation_samples": int(len(list((val_dir).rglob("*.*")))),
        "history": {k: [float(v) for v in vals] for k, vals in history.history.items()},
        "note": "Training history is not a substitute for held-out test evaluation."
    }
    Path("artifacts/training_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print("Training finished. Run evaluate.py against the separate test split before reporting model quality.")

if __name__ == "__main__":
    main()
